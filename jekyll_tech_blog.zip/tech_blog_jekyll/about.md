---
layout: page
title: About Me
permalink: /about/
---

I'm an engineer passionate about simulation, modeling, and tech tools. This blog is where I share what I learn.
