---
layout: home
title: Welcome
---

Welcome to my tech blog! Here you’ll find tutorials, guides, and tips on tools like COMSOL, Python, and more.
